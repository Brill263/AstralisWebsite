# Handoff: Astralis Creative Studio — Marketing Website

## Overview
A multi-page marketing website for **Astralis Creative Studio**, a full-service creative agency in Harare, Zimbabwe (Brand & Digital · Campaigns & Media · Print & Signage · Events & Activations). The site's job is to make the agency look desirable, show the work, and convert visitors into enquiries, with **WhatsApp as the primary conversion channel** and email as the secondary one.

Pages: Home, Work, Services, About, Contact (brief builder), and one case study (DStv Expect+).

## About the Design Files
The files in this bundle are **design references built in HTML/CSS/vanilla JS**. They are working prototypes that show the intended look, copy and behaviour. They are not production code to ship as-is. The task is to **recreate these designs in the target codebase's environment** (e.g. Next.js/Astro/Nuxt, or a CMS theme such as WordPress/Webflow) using its established patterns. If no environment exists yet, a static-site framework such as **Astro or Next.js (static export)** with a headless CMS for Work items is recommended.

The prototype runs as-is if you open `index.html` from a local server, which is useful as a pixel reference.

## Design System
This site follows the **Astralis Creative Studio design system**. The tokens file is included at `design-system/colors_and_type.css` and covers both the deck tokens (green `#8BC53F`) and the web tokens (logo green `#6AE500`, paper `#F7F7F4`, ink `#121217`, cinematic hero base `#0b0b0f`). The **website uses the web tokens**; the deck green `#8BC53F` is for the company profile deck only. Key rules from the system:
- Green is an accent only on the web (dots, arrows, underlines, the final headline word, the WhatsApp CTA). Text on green is always ink.
- No emoji. The only glyphs used are → ↓ ← ✓ × + · •. There is no icon font; the WhatsApp glyph is the only SVG icon.
- Never crop faces in photography (use the object-position values given in the code).
- Motion uses the easing `cubic-bezier(.2,.7,.2,1)` and must respect `prefers-reduced-motion`.

## Fidelity
**High-fidelity.** Colours, typography, spacing, copy, imagery, animation and interactions are final. Recreate them pixel-accurately.

---

## Global Layout & Chrome

### Container
- `.wrap`: `max-width: 1320px; margin: 0 auto; padding: 0 var(--pad)` where `--pad: clamp(20px, 4.5vw, 64px)`.
- Section vertical rhythm: `.sec` `padding: clamp(72px, 9vw, 128px) 0`; `.sec-tight` `clamp(48px, 6vw, 80px) 0`.
- `body` has `padding-top: 76px` (fixed nav height).

### Navigation (all pages; injected by `js/astralis.js`)
- `position: fixed; top:0; height: 76px; z-index: 50`.
- **Glassmorphism**: `background: linear-gradient(180deg, rgba(255,255,255,.62), rgba(255,255,255,.42)); backdrop-filter: blur(22px) saturate(180%); border-bottom: 1px solid rgba(255,255,255,.55); box-shadow: inset 0 1px 0 rgba(255,255,255,.7), 0 8px 32px -12px rgba(18,18,23,.18)`.
- When scrolled (>10px): background goes to `.70 → .50` alpha and the shadow deepens to `0 10px 40px -14px rgba(18,18,23,.25)`.
- Left: colour logo `assets/astralis-logo-color.png`, height 32px.
- Centre links: Home · Work · Services · About · Contact. 15px/500, colour `#3d3d44`, pill hover `rgba(255,255,255,.6)`. The active page link is 600 weight with a 5px green dot centred below it.
- Right: CTA "Start a project →", dark pill button (`.btn-ink`, 44px tall).
- ≤820px: links and CTA hidden; a 44px round burger button opens a full-width dropdown with 22px/600 links.

### Footer (all pages; injected by JS)
- Background `#121217`, text `#9a9aa3`.
- Top row: H2 "Let's make your brand impossible to ignore." (the full stop is green) plus two buttons, "Start a project →" (white) and the email as an outline pill.
- Four columns: logo + blurb / Studio links / Services links (anchor to `services.html#brand|#media|#print|#activations`) / Get in touch (email, phone, WhatsApp, address).
- Base row: "© {year} Astralis Creative Studio. All rights reserved." · "Harare, Zimbabwe".

### Contact data (use everywhere)
- Email: **hello@astraliscreative.studio**
- Phone: **+263 71 939 3784** (`tel:+263719393784`)
- WhatsApp: `https://wa.me/263719393784`
- Address: 05 Tavey Road, Vainona, Borrowdale, Harare
- Hours: Mon–Fri · 8:00–17:00

---

## Screens

### 1. Home (`index.html`)
1. **Hero slider** (`.hs`)
   - Landscape. Height `calc(56.25vw + 76px)` (16:9 below the nav), min 700px, max 100vh. `margin-top: -76px` so it sits behind the glass nav.
   - **The image never sits under the nav.** `.hs-bg` starts at `top: 76px`. The 76px strip behind the glass is filled by `.ext`: the same image, mirrored vertically and blurred (`filter: blur(14px) brightness(.85) saturate(1.2)`). This keeps the models' heads uncropped. Images use `object-position: 78% 0%`.
   - 3 slides, crossfading (opacity 1.2s ease). They auto-advance every **7000ms** via `setInterval`, and any manual navigation resets the timer.
   - Per slide: Ken Burns zoom `scale(1.12 → 1)` over 9s; the kicker line grows to 36px; the headline rises line by line (`translateY(105%) → 0`, 1s `cubic-bezier(.7,0,.2,1)`, staggered 0.35s / 0.47s / 0.59s); the paragraph and CTAs fade up at 0.8s / 0.95s; a diagonal light sweep crosses the hero on each change (1.4s).
   - Overlay: left-to-right dark gradient (`rgba(11,11,15,.92)` → transparent at 75%) plus a bottom fade.
   - Controls: 3 tabs at the bottom left (number + label + a 2px progress bar that fills in 7s), round arrow buttons at the bottom right (50px). Swipe and the ←/→ keys are also supported. Parallax: the bg shifts `±18px` on mouse X.
   - Slide copy:
     | # | Kicker | H1/H2 (3 lines; the last word is green) | Paragraph | Primary CTA | Secondary |
     |---|---|---|---|---|---|
     | 1 | Full-service creative agency | Ideas that make / people stop, stare / and **buy.** | Strategy, creative, film, media, print and live events. One team takes your brand from the brief to the street. | Start your project → `contact.html` | What we do → `services.html` |
     | 2 | Events & activations | Launches the whole / city turns up / **for.** | Concept, stage, talent, crowd and content. We plan it, build it and run it, so all you have to do is show up. | Plan your event → `contact.html?need=Event%20or%20activation` | See a launch we ran → case study |
     | 3 | Campaigns, film & media | Campaigns that / earn attention / and **keep it.** | Big ideas, shot in-house and placed where your audience is actually looking, then measured until they perform. | Brief a campaign → `contact.html?need=Campaign` | View our work → `work.html` |
   - Headline type: `clamp(44px, 5.4vw, 96px)` / 800 / `letter-spacing: -.045em` / `line-height: .98`, white.
2. **Capabilities**: section head "What we do" / "One agency, from the first idea to the last guest out." Then 4 full-width rows (`.cap`): number, H3, description with chips, and a round arrow that turns dark with a green arrow and rotates -45° on hover; the row nudges 12px right on hover. Each links to its services anchor.
3. **Featured work** (dark section): 4 cards (one wide 21:9, three 4:3) from the WORK data. Clicking opens the project modal.
4. **Featured case**: split image/text promo for the DStv Expect+ case with three ticks and the link "Read the case study →".
5. **Results**: 4 stats that count up on scroll (1.4s ease-out cubic): **+40%** engagement lift · **1M+** reach · **+28%** longer sessions · **5 weeks** identity to rollout.
6. **Client logo marquee** (`.lb`): centred line "Trusted by some of Zimbabwe's most recognisable brands" (15px/600, muted). Below it, the logos scroll horizontally in an infinite loop (38s linear; the logo list is duplicated and the track moves -50%), with 40–80px side margins. **Logos are full colour** (no greyscale), height 50px, `mix-blend-mode: multiply`; they scale to 1.12 on hover, and hovering the strip pauses it. The edges fade via a mask gradient.
7. **Process** (dark): 5 steps (Discover, Strategy, Create, Produce, Launch & measure) on a top rule. Each step's dot turns green when it scrolls into view.
8. **CTA band**: dark rounded card (22px radius) with a subtle green glow, "Planning a launch, a campaign or an event?" + "Start a project" + "Chat on WhatsApp".

### 2. Work (`work.html`)
- **Page banner** (`.pb`, shared pattern for all inner pages): `min-height: min(100vh, 800px)`, image from 76px down with the same `.ext` mirrored strip under the glass nav, the same dark gradient, a breadcrumb, a kicker, an H1 that rises line by line (`clamp(40px, 5vw, 80px)`/800, last word green), a paragraph, one CTA (white pill with a ↓ arrow) and a small tag at the bottom right.
  - Work: "Ideas that left / the deck and hit / the **street.**", image `hero-work.jpg`.
- **Filters**: All / Campaigns / Events & activations / Film & photo / Digital, as pills with counts. The active pill is dark.
- **Grid** (`.collage`): **equal 4:3 boxes, 4 columns** (3 at ≤1080px, 2 at ≤720px), 14px gap, 14px radius, 1px border. Tiles fade/scale in with a 60ms stagger. On hover: the image zooms to 1.06, a bottom gradient appears with the category (green, 11px uppercase) and "Client: Title" (18px/800), and a frosted "+" button appears top right. On touch devices captions are always visible.
- **Pagination**: shows 8, then the "View more work (N) ↓" button adds 8 at a time.
- **Click → modal**: two-column dialog (image | body): label, title, description, tag chips, then actions "Read the case study" (if a link exists) and "Start a similar project →", which goes to `contact.html?need=<service>` and pre-selects that service. Close with the ×, a scrim click or Esc.

### 3. Services (`services.html`)
- Banner: "Everything your / brand needs to be / **chosen.**", image `hero-services.jpg`.
- Sticky sub-nav (top 76px) with anchors #brand #media #print #activations. The active link is highlighted while scrolling.
- Four `.studio` sections. Left (sticky): label, H2, lead and an image. Right: a 2-column grid of service cards (white, 1px border, 14px radius, lift on hover), each with H4, description and chips. Brand and Activations end with a full-width dark CTA card.
- "Ways to work with us" (dark): Project / Retainer / Integrated campaign.
- CTA band: "Tell us the goal. We'll work out the plan."

### 4. About (`about.html`)
- Banner: "The people / behind the / **noise.**", image `hero-about.jpg` (a candid team laughing in the studio).
- Story: wide image plus a 2-column prose block (the "why we started Astralis" narrative, in 3 paragraphs).
- Values (dark, 3 cards): Ideas earn their place / Own it end to end / Measure what matters.
- Our studios: 4 columns (Studio, Media, Print, Activations).
- Client logo wall: a 4×2 bordered grid, full-colour logos.
- CTA band.

### 5. Contact / Brief builder (`contact.html`)
- Banner: "Got a brief? / We're all / **ears.**", image `hero-contact.jpg`.
- Two columns (1.3fr / 0.7fr; stacked at ≤1080px):
  - **Form card**, 5 steps:
    1. Services (multi-select chips): Campaign, Event or activation, Roadshow, Stand design and build, Brand identity, Brand strategy, Film and video, Photography, Media buying, Social content, Print and signage, Website or app.
    2. Goal (single): Launch something new / Build awareness / Drive sales or sign-ups / Refresh our brand / Host an experience.
    3. Timing (single): As soon as possible / Within a month / 1–3 months / 3+ months.
    4. Budget (single): Under $5k / $5k–$15k / $15k–$50k / $50k+ / Not sure yet.
    5. Details: Full name*, Company, Email*, Phone/WhatsApp, a "Tell us a bit more" textarea.
    - Selected chips go dark with a green ✓.
  - **Sticky summary (dark card)**: lists the live selections and a brief-strength meter (a 4px green bar; the weights are services 25, goal 15, timing 15, budget 10, name 10, valid email 15, message 10). Then **two submit buttons**:
    - **Primary: "Send brief via WhatsApp"** (green `#6AE500` background, ink text, WhatsApp icon) opens `wa.me/263719393784?text=<formatted brief>` in a new tab.
    - **Secondary: "Send brief via email →"** (outline) opens `mailto:hello@astraliscreative.studio` with the subject "New project enquiry: <first 2 services> (<company or name>)" and the formatted body.
    - Helper text: "WhatsApp gets the fastest reply."
  - **"Prefer to talk?" card** (not duplicated): email, call, WhatsApp, address and hours.
- Validation: name required and email must match `/\S+@\S+\.\S+/`. Invalid fields get a red border (`#d9534f`) and focus moves to the first error.
- Success state: the form steps are replaced by "Your brief is on its way." with channel-specific copy and fallback links.
- URL param `?need=<Service>` pre-selects a chip (case-insensitive match).
- **FAQ** accordion (`<details>`): 5 questions on turnaround, project size, outside Harare, pricing and what happens next.
- **Production TODO:** replace the mailto with a real form backend (e.g. Formspree, HubSpot or a serverless function plus email), keep the WhatsApp deep link, and add analytics events for both submit buttons.

### 6. Case study (`case-dstv-expect.html`)
- Page hero (light) with breadcrumb and H1, then a full-width image, a facts row (Client / Location / Services / Studios involved), prose blocks (Challenge, Approach), two galleries (6-col grid), the 5-step delivery timeline (light variant), a "Next project" row and a CTA band.
- Still uses the older light `.phero` pattern. **Optional:** convert it to the `.pb` banner for consistency.

---

## Interactions & Motion
| Element | Behaviour |
|---|---|
| `.rv` reveal | `opacity 0, translateY(24px)` → visible, 0.8s `cubic-bezier(.2,.7,.2,1)`, via IntersectionObserver (threshold 0.12). Elements already in the viewport on load are revealed immediately, and a **1.5s fallback** reveals everything if the observer never fires. Delay classes `.d1/.d2/.d3` = 70/140/210ms. |
| Buttons | Arrow `.ar` translates 4px right on hover. `.btn-ink` darkens; `.btn-line` outline goes darker or white. |
| Hero slider | See Home section. |
| Marquee | 38s linear infinite; pauses on hover. |
| Counters | Count up once on first view. |
| Modal | Fade plus translateY(20px → 0), 0.4s; body scroll locked. |
| Reduced motion | `prefers-reduced-motion: reduce` disables animation and transitions and shows all content. |

## State
- Hero: `currentIndex`, interval timer.
- Work: `filter` (all / campaign / events / film / digital), `shown` count (8 per page), modal `openId`.
- Contact: `need: Set<string>`, `goal`, `when`, `budget`, form fields, `via: 'wa' | 'email'`, `sent: boolean`.
- WORK data lives in `js/astralis.js` (`window.WORK`), 14 items with fields `{id, img, cat, c (category label), client, t (title), s (short line), d (description), tags[], pos (object-position), contain, link, brief (service to preselect)}`. **Recommended:** move it to a CMS collection.

## Design Tokens
```
Colours
--ink      #121217   (primary text, dark sections)
--ink2     #1b1b21
--ink3     #26262d
--paper    #F7F7F4   (page background)
--white    #FFFFFF
--fog      #EEEEEA   (chips, placeholders)
--line     #E2E2DD   (borders on light)
--line-d   #2c2c33   (borders on dark)
--txt      #3d3d44   (body copy)
--mute     #7c7c84   (muted on light)
--mute-d   #9a9aa3   (muted on dark)
--g        #6AE500   (brand green, sampled from the logo; ACCENTS ONLY: dots, underlines, arrows, last headline word, WhatsApp CTA)
--g-deep   #3E8A00   (green text on light backgrounds)
Hero/banner base  #0b0b0f
Error             #d9534f

Typography
Family: 'Nexa', 'Aptos', 'Montserrat', 'Segoe UI', Arial, sans-serif
  (Montserrat 400/500/600/700/800 from Google Fonts is the web fallback; license Nexa for production if available.)
Body: 17px / 1.6 (16px at ≤560px)
.h-xl  clamp(40px, 5.6vw, 76px)  800  -0.035em  1.02
.h-l   clamp(32px, 3.8vw, 52px)  800  -0.03em   1.08
.h-m   clamp(24px, 2.4vw, 32px)  800  -0.02em   1.15
.h-s   20px                      800  -0.01em   1.3
.lead  clamp(18px, 1.45vw, 20px)  1.6
Label/kicker: 12–13px, 700, letter-spacing .16–.18em, uppercase

Radius:  pills 40px · cards 14px · large cards/CTA 20–22px · modal 20px · inputs 10px
Shadows: nav (see above); modal close button 0 4px 16px rgba(0,0,0,.15)
Buttons: height 52px (44px in nav), padding 0 26px, 15px/600
Breakpoints: 1080px, 900px (hero), 820px (nav), 720px (grid), 560px
```

## Assets
All in `assets/` and bundled in this folder.
- **Logos**: `astralis-logo-color.png`, `astralis-logo-white.png`.
- **Client logos**: `client-dstv-expect.png`, `client-innbucks.png`, `client-b.png` (Dial A Med), `client-chibuku.png` (background removed), `client-d.jpg` (Redan), `client-e.jpg` (Nyaradzo), `client-steers.png` (background removed, lettering recoloured purple for light backgrounds). *EcoCash and Buddie Beatz were intentionally removed from the site.*
- **Hero / banner photography** (1920×1080 JPEG, ~100–220KB, **AI-generated**; replace with a real shoot when available, keeping the subject on the right and dark space on the left): `hero-1.jpg`, `hero-2.jpg` (events slide, the art-direction reference for the others), `hero-3.jpg`, `hero-work.jpg`, `hero-services.jpg`, `hero-about.jpg`, `hero-contact.jpg`.
- **Project photography, AI-upscaled and compressed to WebP** (`assets/hq/`, 1600–1800px wide, 47–436KB): `work-seal`, `work-chibuku`, `work-redan`, `work-dialamed`, `work-kingsman`, `rs-truck`, `dstv-aerial`, `dstv-fbi-stand`, `dstv-showcase`, `rs-crowd`.
- **Other project images (original resolution)**: `dstv-expect-campaign.jpg`, `innbucks-campaign.jpg`, `pv-speaker.jpg`, `pv-group.jpg`, `rs-band.jpg`, `ev-indoor-seating.jpg`, `ev-stage-setup.jpg`. These can be upscaled the same way if needed.
- **Production recommendations:** serve responsive `srcset` sizes (800/1200/1800w), lazy-load below the fold (already set on cards), and preload `hero-1.jpg`.

## SEO / Meta
Each page has a unique `<title>` and meta description. Home and the case study have OG tags. Contact includes a JSON-LD `ProfessionalService` block. Add a sitemap, `robots.txt`, a favicon set and OG images per page in production.

## Files
```
design_handoff_astralis_website/
├── index.html              Home (hero slider, capabilities, work, case, stats, logo marquee, process, CTA)
├── work.html               Work grid + filters + view more + modal
├── services.html           Four studios, sticky sub-nav, engagement models
├── about.html              Story, values, studios, logo wall
├── contact.html            Brief builder (WhatsApp/email), contact card, FAQ
├── case-dstv-expect.html   Case study
├── css/astralis.css        All styles and tokens
├── js/astralis.js          Shared nav/footer injection, reveal, WORK data, modal, banner image extension
├── design-system/colors_and_type.css   Brand tokens (deck + web) and semantic type classes
└── assets/                 Logos, client logos, hero photography, assets/hq/ upscaled work images
```

## Next step: deploy
To build and publish this as a live site, continue in **Genspark Code** with this folder. It can implement the design in a real framework and deploy it.
