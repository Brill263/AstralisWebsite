/* Astralis Creative Studio — shared layout + interactions */
(function(){
const SITE={email:'hello@astraliscreative.studio',phone:'+263 71 939 3784',tel:'+263719393784',wa:'263719393784',
  addr:'05 Tavey Road, Vainona<br>Borrowdale, Harare'};
window.ASTRALIS=SITE;
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const page=document.body.dataset.page||'';

/* ---- nav ---- */
const links=[['index.html','Home','home'],['work.html','Work','work'],['services.html','Services','services'],['about.html','About','about'],['contact.html','Contact','contact']];
const nav=document.createElement('header');nav.className='nav';nav.id='nav';
nav.innerHTML=`<div class="wrap"><a href="index.html" class="logo" aria-label="Astralis Creative Studio, home"><img class="lc" src="assets/astralis-logo-color.png" alt="Astralis Creative Studio"><img class="lw" src="assets/astralis-logo-white.png" alt=""></a>
<ul>${links.map(l=>`<li><a href="${l[0]}" class="${page===l[2]?'on':''}">${l[1]}</a></li>`).join('')}</ul>
<a href="contact.html" class="btn btn-ink nav-cta">Start a project <span class="ar">→</span></a>
<button class="burger" aria-label="Open menu"><span></span><span></span></button></div>`;
document.body.prepend(nav);
nav.querySelector('.burger').onclick=()=>nav.classList.toggle('open');
const darkHero=document.body.dataset.hero==='dark';
const navUpd=()=>{nav.classList.toggle('scrolled',scrollY>10);if(darkHero){const h=document.querySelector('.spot');nav.classList.toggle('ondark',!nav.classList.contains('open')&&h&&h.getBoundingClientRect().bottom>80)}};
addEventListener('scroll',navUpd,{passive:true});navUpd();
nav.querySelector('.burger').addEventListener('click',navUpd);

/* ---- footer ---- */
if(!document.body.dataset.nofoot){
const f=document.createElement('footer');f.className='foot';
f.innerHTML=`<div class="wrap">
<div class="top"><h2 class="h-l">Let's make your brand<br>impossible to ignore<span class="dot">.</span></h2>
<div class="acts"><a href="contact.html" class="btn btn-light">Start a project <span class="ar">→</span></a><a href="mailto:${SITE.email}" class="btn btn-line">${SITE.email}</a></div></div>
<div class="cols">
<div><img src="assets/astralis-logo-white.png" alt="Astralis Creative Studio"><p style="max-width:300px;line-height:1.6">A full-service creative agency in Harare. Strategy, creative, media, print and live experiences under one roof.</p></div>
<div><h6>Studio</h6><a href="work.html">Work</a><a href="services.html">Services</a><a href="about.html">About</a><a href="contact.html">Contact</a></div>
<div><h6>Services</h6><a href="services.html#brand">Brand &amp; Digital</a><a href="services.html#media">Campaigns &amp; Media</a><a href="services.html#print">Print &amp; Signage</a><a href="services.html#activations">Events &amp; Activations</a></div>
<div><h6>Get in touch</h6><a href="mailto:${SITE.email}">${SITE.email}</a><a href="tel:${SITE.tel}">${SITE.phone}</a><a href="https://wa.me/${SITE.wa}" target="_blank" rel="noopener">WhatsApp us</a><p style="line-height:1.6;margin-top:8px">${SITE.addr}</p></div>
</div>
<div class="base"><span>© ${new Date().getFullYear()} Astralis Creative Studio. All rights reserved.</span><span>Harare, Zimbabwe</span></div></div>`;
document.body.append(f);}

/* ---- reveal ---- */
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);if(e.target.dataset.count!==undefined&&!e.target.dataset.done){e.target.dataset.done=1;count(e.target)}}}),{threshold:.12});
window.observeRV=()=>{
  $$('.rv:not(.in),[data-count],.steps').forEach(el=>{
    if(el.getBoundingClientRect().top<innerHeight){el.classList.add('in');if(el.dataset.count!==undefined&&!el.dataset.done){el.dataset.done=1;count(el)}}
    else io.observe(el)});
  clearTimeout(window.__rvT);window.__rvT=setTimeout(()=>$$('.rv:not(.in),.steps:not(.in),[data-count]:not([data-done])').forEach(el=>{el.classList.add('in');if(el.dataset.count!==undefined&&!el.dataset.done){el.dataset.done=1;count(el)}}),1500);
};
function count(el){const to=+el.dataset.count,pre=el.dataset.pre||'',suf=el.dataset.suf||'',t0=performance.now();
  const s=t=>{const p=Math.min(1,(t-t0)/1400),v=Math.round(to*(1-Math.pow(1-p,3)));el.innerHTML=`${pre}${v}<em>${suf}</em>`;if(p<1)requestAnimationFrame(s)};requestAnimationFrame(s)}

/* ---- work data ---- */
window.WORK=[
 {id:'dstv-live',img:'hq/dstv-aerial.webp',cat:'events',c:'Event',client:'DStv Expect+',t:'Expect+ Live at Harare Gardens',s:'A full-scale public launch, designed and run end to end.',d:'We took DStv Expect+ from a product to a moment the city showed up for. We handled concept, permits, stage and site design, artist line-up, crowd activation and full content capture, then reported back with the numbers.',tags:['Event management','Staging','Talent','Site branding'],link:'case-dstv-expect.html',brief:'Event or activation'},
 {id:'dstv-kv',img:'dstv-expect-campaign.jpg',cat:'campaign',c:'Campaign',client:'DStv Expect+',t:'Expect More For Less',s:'A value message, made impossible to scroll past.',pos:'50% 20%',d:'A campaign system built around one simple promise. Key visuals were designed to flex across social, out-of-home and retail, then carried straight through to the live event and the roadshow so every touchpoint felt like the same story.',tags:['Campaign','Key visual','Social','OOH'],brief:'Campaign'},
 {id:'innbucks',img:'innbucks-campaign.jpg',cat:'campaign',c:'Campaign',client:'InnBucks × Visa',t:'Level Up',s:'Launching a partnership with a younger, louder voice.',pos:'50% 25%',d:'For the InnBucks × Visa partnership we built a youth-forward campaign identity with bold colour, confident type and a call to action that travels from a phone screen to a billboard without losing its edge.',tags:['Campaign','Partnership launch','Digital','Print'],brief:'Campaign'},
 {id:'roadshow',img:'hq/rs-truck.webp',cat:'events',c:'Roadshow',client:'DStv Expect+',t:'The City Roadshow',s:'A stage truck and a marching band, straight through the CBD.',pos:'50% 58%',d:'We put the brand on wheels: a fully branded stage truck, a marching band procession and live crowd activation at every stop, so the launch went to where people already were.',tags:['Roadshow','Mobile stage','Street activation'],link:'case-dstv-expect.html',brief:'Roadshow'},
 {id:'seal',img:'hq/work-seal.webp',cat:'film',c:'Film',client:'SEAL',t:'Television Commercial',s:'Broadcast-ready, from script to final grade.',d:'An end-to-end TVC production covering concept, script, casting, shoot, edit, grade and delivery to broadcast spec.',tags:['TVC','Production','Broadcast'],brief:'Film and video'},
 {id:'stand',img:'hq/dstv-fbi-stand.webp',cat:'events',c:'Stand build',client:'DStv',t:'FBI Movies & Series Stand',s:'A themed set guests walked into, not past.',d:'An exhibition stand designed to feel like the show itself. We designed, fabricated and installed it, then hosted guests on the day.',tags:['Stand design','Fabrication','Guest hosting'],link:'case-dstv-expect.html',brief:'Stand design and build'},
 {id:'dialamed',img:'hq/work-dialamed.webp',cat:'digital',c:'Digital product',client:'Dial A Med',t:'Pharmacy App',s:'Making medicine delivery feel effortless.',d:'UI/UX for a pharmacy app covering onboarding, medicine delivery, OTC and wellness shopping, and live chat with a pharmacist, designed to feel calm, clear and trustworthy.',tags:['UI/UX','Mobile app','E-commerce'],brief:'Website or app'},
 {id:'chibuku',img:'hq/work-chibuku.webp',cat:'film',c:'Film',client:'Chibuku',t:'Social Video Ad',s:'Built for the first three seconds.',d:'Social-first video made to hook fast and stay remembered, cut for each platform it runs on.',tags:['Video ad','Social'],brief:'Film and video'},
 {id:'kingsman',img:'hq/work-kingsman.webp',cat:'campaign',c:'Social',client:'Kingsman Clothiers',t:'Tailored for Social',s:'A sharper, more premium voice online.',contain:1,d:'A social campaign that gave a tailoring house the confidence of a luxury label: considered art direction, a consistent grid and copy with some swagger.',tags:['Social campaign','Art direction'],brief:'Social content'},
 {id:'redan',img:'hq/work-redan.webp',cat:'film',c:'Film',client:'Redan',t:'Infomercial',s:'Explains clearly. Sells confidently.',d:'A broadcast infomercial that walks viewers through the offer without losing their attention.',tags:['Infomercial','Broadcast'],brief:'Film and video'},
 {id:'coverage',img:'pv-speaker.jpg',cat:'film',c:'Photo & video',client:'DStv Expect+',t:'Launch Coverage',s:'Every speech, every moment, every handshake.',pos:'50% 35%',d:'Full photo and video coverage of the launch: speakers, stage moments, executive portraits and a same-week highlight reel.',tags:['Event photography','Highlight reel','Portraits'],brief:'Photography'},
];
WORK.push(
 {id:'showcase',img:'hq/dstv-showcase.webp',cat:'events',c:'Brand showcase',client:'DStv',t:'VIP Showcase Evening',s:'Hosted guests, premium moments.',pos:'50% 20%',d:'A hosted showcase for partners and VIP guests, with branded environments, guest management and photo moments throughout the night.',tags:['Showcase','Guest hosting','VIP'],link:'case-dstv-expect.html',brief:'Event or activation'},
 {id:'band',img:'rs-band.jpg',cat:'events',c:'Street activation',client:'DStv Expect+',t:'Marching Band Procession',s:'Turning heads in the CBD.',pos:'60% 60%',d:'A marching band procession led the roadshow through Harare, drawing crowds to every stop.',tags:['Street activation','Roadshow'],link:'case-dstv-expect.html',brief:'Roadshow'},
 {id:'premiere',img:'ev-indoor-seating.jpg',cat:'events',c:'Premiere',client:'DStv Expect+',t:'Indoor Premiere',s:'A seated screening, staged to impress.',pos:'50% 62%',d:'An indoor premiere with stage, screen and seating designed and installed by our team.',tags:['Premiere','Staging','AV'],link:'case-dstv-expect.html',brief:'Event or activation'}
);
window.workCard=(w,cls='')=>`<article class="wc ${cls} rv" data-id="${w.id}" data-cat="${w.cat}" tabindex="0">
<div class="im ${w.contain?'contain':''}"><img src="assets/${w.img}" alt="${w.client}: ${w.t}" loading="lazy" ${w.pos?`style="object-position:${w.pos}"`:''}><span class="view">View <i>→</i></span></div>
<div class="meta"><div><h3>${w.client}: ${w.t}</h3><p>${w.s}</p></div><span class="cat">${w.c}</span></div></article>`;

/* ---- modal ---- */
const m=document.createElement('div');m.className='modal';m.innerHTML=`<div class="scrim" data-x></div><div class="box" role="dialog" aria-modal="true">
<button class="x" data-x aria-label="Close">×</button><div class="media"><img alt=""></div>
<div class="body"><span class="label"></span><h3 class="h-m"></h3><p></p><div class="tags"></div><div class="act"></div></div></div>`;
document.body.append(m);
function openW(id){const w=WORK.find(x=>x.id===id);if(!w)return;
  m.querySelector('.media').classList.toggle('contain',!!w.contain);
  const im=m.querySelector('.media img');im.src='assets/'+w.img;im.alt=w.t;
  m.querySelector('.label').textContent=`${w.c} · ${w.client}`;m.querySelector('.h-m').textContent=w.t;m.querySelector('.body p').textContent=w.d;
  m.querySelector('.tags').innerHTML=w.tags.map(t=>`<span class="chip">${t}</span>`).join('');
  m.querySelector('.act').innerHTML=(w.link?`<a href="${w.link}" class="btn btn-line">Read the case study</a>`:'')+`<a href="contact.html?need=${encodeURIComponent(w.brief)}" class="btn btn-ink">Start a similar project <span class="ar">→</span></a>`;
  m.classList.add('open');document.body.style.overflow='hidden'}
const close=()=>{m.classList.remove('open');document.body.style.overflow=''};
m.querySelectorAll('[data-x]').forEach(x=>x.onclick=close);
addEventListener('keydown',e=>e.key==='Escape'&&close());
document.addEventListener('click',e=>{const c=e.target.closest('.wc');if(c&&!c.dataset.href)openW(c.dataset.id)});
document.addEventListener('keydown',e=>{if(e.key==='Enter'){const c=e.target.closest&&e.target.closest('.wc');if(c)openW(c.dataset.id)}});

function addExt(){$$('.hs-slide,.pb').forEach(el=>{if(el.querySelector(':scope>.ext'))return;const im=el.querySelector('img');if(!im)return;const d=document.createElement('div');d.className='ext';d.setAttribute('aria-hidden','true');d.style.setProperty('--img',`url("${im.getAttribute('src')}")`);el.prepend(d)})}
document.addEventListener('DOMContentLoaded',()=>{addExt();window.observeRV()});
if(document.readyState!=='loading')addExt();
if(document.readyState!=='loading')setTimeout(()=>window.observeRV(),0);
})();
